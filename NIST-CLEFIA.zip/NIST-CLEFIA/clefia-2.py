#!/usr/bin/env python3

def convert_to_128bit(number):
    """Convert a number to 128-bit binary representation"""
    binary = bin(number)[2:]
    return binary.zfill(128)

def main():
    filename = "128bit_numbers.txt"
    
    with open(filename, 'w') as f:
        for i in range(1, 7815):  # 1 to 7814 inclusive
            bit_representation = convert_to_128bit(i)
            f.write(f"{bit_representation}\n")
    
    print(f"Wrote 128-bit representations to '{filename}'")

if __name__ == "__main__":
    main()