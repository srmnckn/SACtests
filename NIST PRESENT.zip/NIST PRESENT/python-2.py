#!/usr/bin/env python3

def convert_to_nbit(number, nbits):
    """Convert a number to n-bit binary representation"""
    binary = bin(number)[2:]
    return binary.zfill(nbits)

def calculate_required_count(nbits, target_bits=1_000_000):
    """Calculate how many numbers are needed to strictly exceed target_bits"""
    count = target_bits // nbits
    if count * nbits < target_bits:
        count += 1
    return count

def main():
    try:
        nbits = int(input("Enter the number of bits (e.g., 32, 64, 128): "))
        if nbits <= 0:
            raise ValueError("Bit size must be a positive integer.")
    except ValueError as e:
        print(f"Invalid input: {e}")
        return

    count = calculate_required_count(nbits)
    total_bits = count * nbits
    filename = f"{nbits}bit_numbers.txt"

    with open(filename, 'w') as f:
        for i in range(1, count + 1):
            bit_representation = convert_to_nbit(i, nbits)
            f.write(f"{bit_representation}\n")

    print(f"Wrote {count} numbers ({total_bits} bits total) to '{filename}'")

if __name__ == "__main__":
    main()
